import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./compiled-tailwind.css";
import AuthProvider from "@/components/AuthProvider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Stock Alpha - Live Indian Stock Market & Portfolio Analysis",
  description: "Real-time NSE/BSE stock screener, interactive charting, order history consolidation, and institutional portfolio health analysis.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col">
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
