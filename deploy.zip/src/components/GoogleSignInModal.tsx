'use client';

import React, { useState, useEffect } from 'react';
import { X, Check, Shield, User, LogOut } from 'lucide-react';

export interface UserProfile {
  name: string;
  email: string;
  picture?: string;
  isSignedIn: boolean;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile | null;
  onSignIn: (profile: UserProfile) => void;
  onSignOut: () => void;
}

export default function GoogleSignInModal({ isOpen, onClose, user, onSignIn, onSignOut }: Props) {
  const [emailInput, setEmailInput] = useState('');
  const [nameInput, setNameInput] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSimulatedGoogleOAuth = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      const email = emailInput.trim() || 'investor@gmail.com';
      const name = nameInput.trim() || email.split('@')[0].replace('.', ' ').replace(/\b\w/g, l => l.toUpperCase());
      const profile: UserProfile = {
        name,
        email,
        picture: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(name)}`,
        isSignedIn: true
      };
      onSignIn(profile);
      setIsSubmitting(false);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-2xl max-w-md w-full p-6 relative overflow-hidden">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {user?.isSignedIn ? (
          /* User is already signed in */
          <div className="text-center py-4 space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-50 border-2 border-emerald-500/20 mx-auto overflow-hidden flex items-center justify-center shadow-xs">
              {user.picture ? (
                <img src={user.picture} alt={user.name} className="w-full h-full object-cover" />
              ) : (
                <User className="w-8 h-8 text-emerald-600" />
              )}
            </div>
            <div>
              <div className="flex items-center justify-center gap-1.5 text-xs text-emerald-600 font-bold mb-1">
                <Check className="w-4 h-4" /> Signed in with Google Cloud
              </div>
              <h2 className="text-xl font-bold text-slate-900">{user.name}</h2>
              <p className="text-xs text-slate-500 font-mono mt-0.5">{user.email}</p>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 text-left text-xs text-slate-600 space-y-1.5">
              <div className="flex items-center gap-2 font-semibold text-slate-800">
                <Shield className="w-4 h-4 text-emerald-600" /> Google Cloud OAuth 2.0 Connected
              </div>
              <p className="text-[11px] text-slate-500">
                Your portfolio, custom stock watchlists, and algorithmic orders are secured and synced across your devices.
              </p>
            </div>

            <div className="pt-2 flex items-center gap-3">
              <button
                onClick={onSignOut}
                className="flex-1 py-2.5 px-4 rounded-xl border border-rose-200 bg-rose-50/50 hover:bg-rose-50 text-rose-600 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <LogOut className="w-4 h-4" /> Sign Out
              </button>
              <button
                onClick={onClose}
                className="flex-1 py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all cursor-pointer shadow-xs"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          /* Sign-In flow */
          <div className="space-y-5">
            <div className="text-center pt-2">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 border border-emerald-100 mx-auto flex items-center justify-center mb-3">
                <Shield className="w-6 h-6" />
              </div>
              <h2 className="text-xl font-bold text-slate-900">Sign in to Stock Alpha</h2>
              <p className="text-xs text-slate-500 mt-1">
                Authenticate with Google Cloud to sync your Indian stock portfolio &amp; order history
              </p>
            </div>

            {/* Official Google OAuth 1-Click Button */}
            <button
              onClick={handleSimulatedGoogleOAuth}
              disabled={isSubmitting}
              className="w-full py-3 px-4 rounded-2xl border border-slate-300 hover:border-slate-400 bg-white hover:bg-slate-50/80 transition-all flex items-center justify-center gap-3 shadow-xs cursor-pointer group disabled:opacity-50"
            >
              {/* Google 4-color 'G' SVG icon */}
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span className="text-xs font-bold text-slate-700 group-hover:text-slate-900">
                {isSubmitting ? 'Authenticating with Google Cloud...' : 'Continue with Google'}
              </span>
            </button>

            <div className="relative flex items-center justify-center">
              <div className="border-t border-slate-200 w-full" />
              <span className="bg-white px-3 text-[10px] uppercase font-bold text-slate-400 absolute">
                or sign in with email
              </span>
            </div>

            <div className="space-y-2.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Your Full Name</label>
                <input
                  type="text"
                  placeholder="e.g. Rahul Sharma"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-emerald-500 bg-slate-50/50 focus:bg-white transition-all font-medium"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Google / Workspace Email</label>
                <input
                  type="email"
                  placeholder="e.g. rahul.sharma@gmail.com"
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-emerald-500 bg-slate-50/50 focus:bg-white transition-all font-mono"
                />
              </div>

              <button
                onClick={handleSimulatedGoogleOAuth}
                disabled={isSubmitting}
                className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all cursor-pointer shadow-xs disabled:opacity-50 mt-1"
              >
                Sign In &amp; Sync Portfolio
              </button>
            </div>

            <p className="text-[10px] text-center text-slate-400">
              Protected by Google Cloud IAM &amp; OAuth 2.0 security. Your credentials never touch third-party servers.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
